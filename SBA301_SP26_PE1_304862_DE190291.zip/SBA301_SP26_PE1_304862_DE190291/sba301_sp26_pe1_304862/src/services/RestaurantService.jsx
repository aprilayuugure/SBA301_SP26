import api from "../api/axiosInstance";

const RestaurantService = {
    searchRestaurants: (q = {}) => {
        const params = {
            page: q.page ?? 0,
            size: q.size ?? 10,
            sortBy: q.sortBy || "restaurantName",
        };

        const name = String(q.name ?? "").trim();
        const category = String(q.category ?? "").trim();
        if (name) params.name = name;
        if (category) params.category = category;

        return api.get("/restaurants/search", { params });
  },
  
  getRestaurantById: (id) => api.get(`/restaurants/${id}`),

  addRestaurant: (data) => api.post("/shoes", data),

  updateRestaurant: (id, data) => api.put("/restaurants/${id}", data),

  deleteShoes: (id) => api.delete(`/shoes/${id}`),
}

export default RestaurantService;